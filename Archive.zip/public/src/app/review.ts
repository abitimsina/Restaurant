
export interface Review {
  name: string;
  stars: number;
  content: string;
}

